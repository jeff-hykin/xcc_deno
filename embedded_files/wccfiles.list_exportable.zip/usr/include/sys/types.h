#pragma once

typedef long ssize_t;

typedef int pid_t;
typedef long off_t;
