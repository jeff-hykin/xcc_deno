#pragma once

#define bool   _Bool
#define false  (0)
#define true   (1)
