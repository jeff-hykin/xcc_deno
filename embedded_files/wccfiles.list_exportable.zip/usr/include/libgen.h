#pragma once

char *dirname(char *);
char *basename(char *);
